//
// Smpl_GPIO_LED4 : GPC12 ~ 15 to control on-board LEDs
//                  low-active output
//                  run forward (12->15) then backward (15->12)
//
#include <stdio.h>
#include "NUC1xx.h"
#include "GPIO.h"
#include "SYS.h"

// Initial GPIO pins (GPC 12,13,14,15) to Output mode
void Init_LED()
{
	// initialize GPIO pins
	DrvGPIO_Open(E_GPC, 12, E_IO_OUTPUT);	// GPC12 pin set to output mode
	DrvGPIO_Open(E_GPC, 13, E_IO_OUTPUT);	// GPC13 pin set to output mode
	DrvGPIO_Open(E_GPC, 14, E_IO_OUTPUT);	// GPC14 pin set to output mode
	DrvGPIO_Open(E_GPC, 15, E_IO_OUTPUT);	// GPC15 pin set to output mode
	// turn off all four LEDs
	DrvGPIO_SetBit(E_GPC, 12);	// GPC12 pin output Hi to turn off LED
	DrvGPIO_SetBit(E_GPC, 13);	// GPC13 pin output Hi to turn off LED
	DrvGPIO_SetBit(E_GPC, 14);	// GPC14 pin output Hi to turn off LED
	DrvGPIO_SetBit(E_GPC, 15);	// GPC15 pin output Hi to turn off LED
}

int main (void)
{
	int32_t i;		// LED pin number

	UNLOCKREG();		// unlock register for programming
	DrvSYS_Open(50000000);	// set System Clock to run at 50MHz
	LOCKREG();		// lock register from programming

	Init_LED();		// Initialize LEDs (four on-board LEDs below LCD panel)

	while (1)		// forever loop
	{
		// forward : GPC12 -> GPC13 -> GPC14 -> GPC15
		for (i = 12; i <= 15; i++)
		{
			DrvGPIO_ClrBit(E_GPC, i);	// output Low to turn on LED
			DrvSYS_Delay(300000);		// delay
			DrvGPIO_SetBit(E_GPC, i);	// output Hi to turn off LED
		}

		// backward : GPC15 -> GPC14 -> GPC13 -> GPC12
		for (i = 15; i >= 12; i--)
		{
			DrvGPIO_ClrBit(E_GPC, i);	// output Low to turn on LED
			DrvSYS_Delay(300000);		// delay
			DrvGPIO_SetBit(E_GPC, i);	// output Hi to turn off LED
		}
	}
}
